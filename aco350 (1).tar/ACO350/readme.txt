File		Notes
================================================================================================================================================================================
Mod1		All of the source code and project starter code for Module 1: Introduction
Mod2		All of the source code and project starter code for Module 2: Processes and Threads
Mod3		All of the source code and project starter code for Module 3: Synchronization and Deadlocks
Mod4		All of the source code and project starter code for Module 4: Memory
Mod5		All of the source code and project starter code for Module 5: I/O, Storage and File Systems
makefile	This makefile will compile all of the source code in these directories. Specificlly, you can:
		   make all	// Compiles all of the code
		   make clean   // Deletes all of the generated files (executables and .class files). These can be remade with the command above.
		   make tar	// This will remake the tar file. You may want to do this at the end of the semester to collect up all of the source including your projects
