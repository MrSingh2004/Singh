#include <stdio.h>
#include <string.h>

#define NAME_LENGTH 25

int main(int argc, char *argv[]) {
   FILE *in, *out;   
   int c;

   if (argc != 3) {
      fprintf(stderr, "Usage: %s <input file> <output file>\n", argv[0]);
      return 0;
   }

   if (strcmp(argv[1], argv[2]) == 0) {
      fprintf(stderr, "Source and destination files must be unique\n");
      return 0;
   }


   if ( (in = fopen(argv[1], "r")) == NULL) {
      fprintf(stderr, "Cannot open %s for reading\n", argv[1]);
      return -1;
   }
   if ( (out = fopen(argv[2], "w")) == NULL) {
      fprintf(stderr, "Cannot open %s for writing\n", argv[2]);
      return -1;
   }

   while ( (c = getc(in)) != EOF)
      putc(c,out);

   fclose(in);
   fclose(out);
}
