C:				Lecture		Notes
================================================================================================================================================
copy1.c				ACO350_1d.pdf	Example of a file copy utility in C
copy2.c				ACO350_1d.pdf	Example of a file copy utility in C
copy3.c				ACO350_1d.pdf	Example of a file copy utility in C
helloACO.c			ACO350_0a.pdf	C program to compile and run as part of the assignment "Project 1a - Accessing Linux"
makefile					makefile to compile (make all) or delete (make clean)

Java:				Lecture		Notes
================================================================================================================================================
FileCopy.java			ACO350_1d.pdf	Example of a file copy utility in Java
makefile					makefile to compile (make all) or delete (make clean)

sysutil:			Lecture		Notes
================================================================================================================================================
sysutil.c			ACO350_1d.pdf	Starter C program to be completed for the assignment "Project 1b - System Information Utility"
makefile					makefile to compile (make all) or delete (make clean)
