/**
 * Copy files a little more efficiently than the first solution.
 * This provides three different approaches:
 *
 * (1) as a series of single byte reads.
 * (2) as one big read.
 * (3) as a series of 1 KB reads.
 *
 * Usage:
 *   java FileCopy <input file> <output file>
 *
 * @author Greg Gagne - Jan. 2006
 */

import java.io.*;

public class FileCopy {
   public static void main(String[] args) throws IOException {
      InputStream inFile = null;
      OutputStream outFile = null;

                /** Ensure that exactly two parameter are passed on the command line */
      if (args.length != 2) {
         System.err.println("Usage: FileCopy <input file> <output file>");
         System.exit(0);
      }

      /** 
       * Ensure that the source and destination files are unique.
       * Otherwise it is possible the destination file could overwrite the source file
       * thus creating an empty source file.
       */
      if (args[0].equals(args[1])) {
         System.err.println("Source and destination files must be unique");
         System.exit(0);
      }
      
      try {
         inFile = new FileInputStream(args[0]);
         outFile = new FileOutputStream(args[1]);

         /**
          * we must use an integer when reading from an input stream even
          * though read returns a byte. the reason for this is that java
          * does not  provide an unsigned byte - only signed bytes. To get
          * the full 8 bits, we must use an int. However, we only use the 
          * low order byte of the int, the 3 remaining bytes are unused.
          */

         /**
          * METHOD #1 - AS A SERIES OF 1 BYTE READS.
          * THIS IS THE LEAST EFFICIENT APPROACH

         int byteRead;
         while ( (byteRead = inFile.read()) != -1)
            outFile.write(byteRead);
                 */
      
         /**
          * METHOD #2 - AS ONE BIG READ/WRITE
          * available() returns the number of bytes that can be
          * read from the stream without blocking.
          *
          * This is a very fast way of reading the file.
          * However the available() method will only work for
          * a file that is on disk and may not necessarily return the size
          * of the file from a network URL.
         */

         int bytesToRead = inFile.available();
         byte[] bytesOne = new byte[bytesToRead];
         inFile.read(bytesOne);
         outFile.write(bytesOne);

         /**
          * METHOD #3 - AS A SERIES of 1 KB READS.
          * Although it could be any size read.
          
         byte[] bytesTwo = new byte[1024];
         int bytesRead = 0;

         while ( (bytesRead = inFile.read(bytesTwo)) > 0) 
            outFile.write(bytesTwo,0,bytesRead);
         */
      }
      catch (FileNotFoundException fnfe) {
         System.err.println("File " + args[0] + " not found.");
      }
      finally { /** This ensures streams get closed in case we get some type of exception */
         if (inFile != null)
            inFile.close();
         if (outFile != null)
            outFile.close();
      }
   }
}

