#include <stdio.h>

int main(int argc, char *argv[]) {
   printf("*****************************\n");
   printf("*** ACO350 - Your Name    ***\n");
   printf("***  System Info Utility  ***\n");
   printf("*****************************\n\n");

   return 0;
}
