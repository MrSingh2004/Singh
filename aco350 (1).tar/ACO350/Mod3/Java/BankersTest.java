import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

class BankersTest {
   public static void main(String[] args) {
      Scanner in = new Scanner(System.in);

      System.out.print("Total number of threads: ");
      int n = in.nextInt();

      System.out.print("Total number of resources: ");
      int m = in.nextInt();

      int available[] = new int[m];
      for (int j = 0; j < m; j++) {
         System.out.printf("Available instances of resource R(%d): ", j);
         available[j] = in.nextInt();
      }

      int max[][] = new int[n][m];
      for (int i = 0; i < n; i++) {
         for (int j = 0; j < m; j++) {
            System.out.printf("Thread T(%d) may request, at most, how many instances of resource type R(%d): ", i,
                  j);
            max[i][j] = in.nextInt();
         }
      }

      int allocation[][] = new int[n][m];
      for (int i = 0; i < n; i++) {
         for (int j = 0; j < m; j++) {
            System.out.printf("Thread T(%d) is currently allocated how many instances of resource type R(%d): ", i,
                  j);
            allocation[i][j] = in.nextInt();
         }
      }
      System.out.println("\n\nInitial State Analysis:");

      ArrayList<Integer> sequence = new ArrayList<>();
      try {
         if (Bankers.safety(sequence, available, max, allocation, n, m, true)) {
            System.out.print("\nThe system is in a safe state. The safe sequence is: ");
            for (int t : sequence)
               System.out.printf("T%d ", t);
            System.out.println("\n");
         } else
            System.out.println("\nThe system is not in a safe state.\n");
      } catch (AllocationException ae) {
         System.out.printf("Error: " + ae.getMessage());
         System.exit(1);
      }

      System.out.println("Request Analysis:");
      int numRequests = in.nextInt();
      int request[] = new int[m];

      for (int q = 0; q < numRequests; q++) {
         int processNum = in.nextInt();
         for (int r = 0; r < m; r++) {
            request[r] = in.nextInt();
         }
         try {
            boolean reqTest = Bankers.requestResources(processNum, request, available, max, allocation, n, m);
            System.out.printf("   %d) T%d request for %s %s\n", q, processNum, Arrays.toString(request),
                  reqTest ? "succeeded" : "failed");
         } catch (AllocationException ae) {
            System.out.printf("   %d) Error: " + ae.getMessage() + "\n", q);
         }
      }

      in.close();
   }
}
