import java.util.Arrays;

public class Stack_m<T> {

    private final static int DEFAULT_CAPACITY = 100;
    private int top;  
    private T[] stack;
    
    public Stack_m() {
        this(DEFAULT_CAPACITY);
    }

    @SuppressWarnings("unchecked")
    public Stack_m(int initialCapacity) {
        top = 0;
        stack = (T[])(new Object[initialCapacity]);
    }

    synchronized public void push(T element) {
        if (size() == stack.length) 
            expandCapacity();

        stack[top] = element;
        top++;
    }

    private void expandCapacity() {
        stack = Arrays.copyOf(stack, stack.length * 2);   
    }

    synchronized public T pop() {
        if (isEmpty())
            return null;

        top--;
        T result = stack[top];
        stack[top] = null; 

        return result;
    }
   
    synchronized public T peek() {
        if (isEmpty())
            return null;

        return stack[top-1];
    }
    
    public boolean isEmpty() {
    	return top == 0;
    }
    
    public int size() {
    	return top;
    }    
}
