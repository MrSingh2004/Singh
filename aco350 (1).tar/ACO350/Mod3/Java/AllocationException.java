public class AllocationException extends Exception {
   public AllocationException(String s) {
      super(s);
   }
}
