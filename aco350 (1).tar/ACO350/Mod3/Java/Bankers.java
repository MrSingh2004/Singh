import java.util.ArrayList;

class Bankers {
   static boolean safety(ArrayList<Integer> safeSequence, int available[], int max[][], int allocation[][], int n,
         int m, boolean verbose) throws AllocationException {

      // Initialize the work array with the initial values of the available array.
      // This array tracks the currently available resources and changes as threads
      // release or request resources.
      int[] work = new int[m];
      for (int i = 0; i < m; i++)
         work[i] = available[i];

      // Calculate the need matrix[process#][resource#] as the difference between the
      // max and allocation matrices.
      int[][] need = new int[n][m];
      for (int i = 0; i < n; i++) {
         for (int j = 0; j < m; j++) {
            need[i][j] = max[i][j] - allocation[i][j];
            if (need[i][j] < 0) {
               throw new AllocationException(
                     String.format("T%d needs %d instances of resource %d, but already has %d.", i, max[i][j], j,
                           allocation[i][j]));
            }
         }
      }

      // Initialize the finish array with all false values, indicating that no task is
      // done yet.
      boolean[] finish = new boolean[n];
      for (int i = 0; i < n; i++)
         finish[i] = false;

      // Print the initial state (if in VERBOSE mode)
      if (verbose)
         printState(allocation, need, work, finish, n, m);

      boolean changed = true;
      // The loop continues to looking for another possible allocation as long as
      // progress is being made
      // That is, as long as some process has changed.
      while (changed) {
         changed = false; // Assume no process changes
         // For each Thread i...
         for (int i = 0; i < n; i++) {
            if (!finish[i]) { // If its not finished...

               // Check if the needed resources is less than the available (work) resources...
               boolean needsIsLessThanWork = true;
               for (int j = 0; j < m; j++)
                  needsIsLessThanWork &= (need[i][j] <= work[j]);

               // If not, this thread cannot make progress yet. Go on to the next one.
               if (!needsIsLessThanWork)
                  continue;

               // This thread has all the resources it needs to complete.
               // Return its resources to the available resources (work).
               for (int k = 0; k < m; k++)
                  work[k] += allocation[i][k];

               // Add it as the next completing thread in the safe sequence and mark it
               // finished.
               if (safeSequence != null)
                  safeSequence.add(i);
               finish[i] = true;

               // Something has changed, so its worth running the loop again.
               changed = true;

               // Report the latest completed thread (if in VERBOSE mode)
               if (verbose) {
                  System.out.printf("\nAdding T%d to the safe sequence.\n", i);
                  printState(allocation, need, work, finish, n, m);
               }
            }
         }
      }

      // We get here when no more changes can be made to our threads.
      // Return true if ALL of the threads are finished.
      boolean safeState = true;
      for (int i = 0; i < n; i++)
         safeState &= finish[i];

      return safeState;
   }

   public static boolean requestResources(int p, int request[], int available[], int max[][], int allocation[][],
         int n, int m) throws AllocationException {

      // Run some checks first:
      // 1) Thread number is valid
      // 2) A request for a resource does not exceed the number the thread said it
      // required.
      // 3) A request does not exceed the maximum that are possible.
      if (p >= n) {
         throw new AllocationException(String.format("Illegal thread: T%d", p));
      }

      for (int i = 0; i < m; i++) {
         if (request[i] > (max[p][i] - allocation[p][i])) {
            throw new AllocationException(String.format("T%d request for R%d exceeds maximum claim", p, i));
         }
      }

      for (int i = 0; i < m; i++) {
         if (request[i] > available[i]) {
            throw new AllocationException(String.format("T%d request for R%d exceeds available resources", p, i));
         }
      }

      // Initialize the work array with the initial values of the available array.
      // This array tracks the currently available resources and changes as threads
      // release or request resources.
      int[] availTemp = new int[m];
      for (int i = 0; i < m; i++)
         availTemp[i] = available[i];

      int[][] allocTemp = new int[n][m];
      for (int i = 0; i < n; i++)
         for (int j = 0; j < m; j++)
            allocTemp[i][j] = allocation[i][j];

      // Reduce the available resources by the requested amounts.
      for (int i = 0; i < m; i++) {
         availTemp[i] = available[i] - request[i];
         allocTemp[p][i] = allocation[p][i] + request[i];
      }

      // Do a safety check with the new allocations.
      return safety(null, availTemp, max, allocTemp, n, m, false);
   }

   public static void printState(int allocation[][], int need[][], int available[], boolean finish[], int n, int m) {
      String space = "                                                           ";
      int a_width = Math.max(12, 4 * m + 1);
      int a_pad = Math.max(a_width - (4 * m + 1), 0);
      int n_width = Math.max(6, 4 * m + 1);
      int n_pad = Math.max(n_width - (4 * m + 1), 0);
      int v_width = Math.max(10, 4 * m + 1);
      int v_pad = Math.max(v_width - (4 * m + 1), 0);

      System.out.println();
      String format = "%-7s |%-" + a_width + "s|%-" + n_width + "s|%-" + v_width + "s|\n";
      System.out.printf(format, "", " Allocation ", " Need ", " Available ");

      System.out.printf("Thread  |");
      for (int i = 0; i < m; i++) {
         System.out.printf(" R%-2d", i);
      }
      System.out.printf("%s |", space.substring(0, a_pad));
      for (int i = 0; i < m; i++) {
         System.out.printf(" R%-2d", i);
      }
      System.out.printf("%s |", space.substring(0, n_pad));
      for (int i = 0; i < m; i++) {
         System.out.printf(" R%-2d", i);
      }
      System.out.printf("%s |\n", space.substring(0, v_pad));

      for (int i = 0; i < n; i++) {
         System.out.printf("%-7s |", finish[i] ? ("<T" + i + ">") : ("T" + i));
         for (int j = 0; j < m; j++) {
            System.out.printf(" %-3d", allocation[i][j]);
         }
         System.out.print(" |");
         for (int j = 0; j < m; j++) {
            System.out.printf(" %-3d", need[i][j]);
         }
         System.out.print(" |");
         if (i == 0) {
            for (int j = 0; j < m; j++) {
               System.out.printf(" %-3d", available[j]);
            }
         } else {
            System.out.printf("%s", space.substring(0, v_width - 1));
         }
         System.out.println(" |");
      }
   }
}
