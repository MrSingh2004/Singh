#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

#define NUM_READERS	5
#define NUM_WRITERS	5

sem_t rw_mutex;		// Binary  : 1 - RW access available
sem_t mutex;		// Binary  : 1 - Access granted to read_count
int   read_count = 0;	// Number of readers accessing the data

typedef struct {
   int process_id;
   int num_accesses;
} instruction_t;

void *writer(void *);
void *reader(void *);
void init_random();
int get_random(int, int);
void sleep_random(int, int);


void main() {
   init_random();

   sem_init(&rw_mutex, 0, 1);
   sem_init(&mutex,    0, 1);

   pthread_attr_t attr;
   pthread_attr_init(&attr);

   pthread_t writer_tids[NUM_WRITERS];
   for(int i = 0; i < NUM_WRITERS; i++) {
      instruction_t *s = (instruction_t *) malloc(sizeof(instruction_t)); 
      s->process_id = i+1;
      s->num_accesses = 3;

      pthread_create(&writer_tids[i], &attr, writer, s);
   }

   pthread_t reader_tids[NUM_READERS];
   for(int i = 0; i < NUM_READERS; i++) {
      instruction_t *s = (instruction_t *) malloc(sizeof(instruction_t)); 
      s->process_id = i+1;
      s->num_accesses = 10;

      pthread_create(&reader_tids[i], &attr, reader, s);
   }

   for(int i = 0; i < NUM_WRITERS; i++) {
      pthread_join(writer_tids[i], NULL);
   }

   for(int i = 0; i < NUM_READERS; i++) {
      pthread_join(reader_tids[i], NULL);
   }
}

void *reader(void *param) {
   instruction_t *x = (instruction_t *)param;
   sleep_random(1000000, 3000000);
   printf("Reader %d: Started\n", x->process_id);

   for (int access_count = 1; access_count <= x->num_accesses; access_count++) {
      sem_wait(&mutex);
      read_count++;
      if (read_count == 1)
         sem_wait(&rw_mutex);
      sem_post(&mutex);

      printf("Reader %d is reading #%d (%d reading now)\n", x->process_id, access_count, read_count);
      sleep_random(1000000, 3000000);

      sem_wait(&mutex);
      read_count--;
      if (read_count == 0)
         sem_post(&rw_mutex);
      sem_post(&mutex);
   }
   pthread_exit(0);
}

void *writer(void *param) {
   instruction_t *x = (instruction_t *)param;
   printf("Writer %d: Started\n", x->process_id);

   for (int access_count = 1; access_count <= x->num_accesses; access_count++) {
      sem_wait(&rw_mutex);

      printf("Writer %d is writing #%d (%d reading now)\n", x->process_id, access_count, read_count);
      sleep_random(1000000, 3000000);

      sem_post(&rw_mutex);
   }
   pthread_exit(0);
}

void init_random() {
   time_t t;
   srand((unsigned) time(&t));
}

int get_random(int min, int max) {
   return (int)(rand() % (max - min)) + min;
}

void sleep_random(int min, int max) {
   usleep(get_random(min, max));
}
