#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define TRUE  1
#define FALSE 0

int turn = 0;
int flag[2];

void *peterson(void *param);

int main(int argc, char *argv[]) {
   pthread_t tid0, tid1;
   pthread_attr_t attr;

   printf("Peterson\n");
   flag[0] = FALSE;
   flag[1] = FALSE;

   /* get the default attributes */
   pthread_attr_init(&attr);

   /* create the threads */
   int val0 = 0;
   int val1 = 1;
   pthread_create(&tid0, &attr, peterson, &val0);
   pthread_create(&tid1, &attr, peterson, &val1);

   /* now wait for the threads to exit */
   pthread_join(tid0, NULL);
   pthread_join(tid1, NULL);

   printf("Done\n");
}

void *peterson(void *param) {
   int i = *((int *)param);
   int j = 1 - i;

   printf("Starting P%d\n", i);

   while (TRUE) {
      flag[i] = TRUE;
      turn = j;
      while (flag[j] && turn == j)
         ;

      /* Critical Section */
      printf("P%d in critical section\n", i);
      sleep(1);
      flag[i] = FALSE;

      /* Remainder Section */
      printf("P%d in remainder section\n", i);
      sleep(1);
   }
}
