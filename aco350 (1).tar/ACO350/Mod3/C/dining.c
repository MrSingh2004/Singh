#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

#define NUM_PHILOSOPHERS	5
#define NUM_MEALS		3

void test(int i);
void init_random();
int get_random(int, int);
void sleep_random(int, int);

enum { THINKING, HUNGRY, EATING } state[NUM_PHILOSOPHERS];

sem_t self[NUM_PHILOSOPHERS];
sem_t chopstick[NUM_PHILOSOPHERS];

typedef struct {
   int philosopher_id;
} instruction_t;

void *philosopher(void *);

void main() {
   printf("Dining Philosophers -- starting.\n");
   init_random();

   for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
      sem_init(&self[i],      0, 1);
      sem_init(&chopstick[i], 0, 1);
      state[i] = THINKING;
   }

   pthread_attr_t attr;
   pthread_attr_init(&attr);

   pthread_t philosopher_tids[NUM_PHILOSOPHERS];

   for(int i = 0; i < NUM_PHILOSOPHERS; i++) {
      instruction_t *s = (instruction_t *) malloc(sizeof(instruction_t)); 
      s->philosopher_id = i;

      pthread_create(&philosopher_tids[i], &attr, philosopher, s);
      sleep_random(1000000, 3000000);
   }

   for(int i = 0; i < NUM_PHILOSOPHERS; i++) {
      pthread_join(philosopher_tids[i], NULL);
   }

   printf("Dining Philosophers -- done.\n");
}

void *philosopher(void *param) {
   instruction_t *x = (instruction_t *)param;
   int i = x->philosopher_id;
   
   printf("Philosopher %d exists.\n", x->philosopher_id);

   for (int count = 1; count <= NUM_MEALS; count++) {
      sem_wait(&chopstick[i]);
      sem_wait(&chopstick[(i + 1) % NUM_PHILOSOPHERS]);
   
      printf("Philosopher %d starts eating (#%d)\n", x->philosopher_id, count);
      sleep_random(500000, 1500000);
      printf("Philosopher %d finishes eating (#%d)\n", x->philosopher_id, count);

      sem_post(&chopstick[i]);
      sem_post(&chopstick[(i + 1) % NUM_PHILOSOPHERS]);

      printf("Philosopher %d is thinking\n", x->philosopher_id);
   }
}

void pickup(int i) {
   state[i] = HUNGRY;
   test(i);
   if (state[i] != EATING)
      sem_wait(&self[i]);
}

void putdown(int i) {
   state[i] = THINKING;

   test((i + NUM_PHILOSOPHERS - 1) % NUM_PHILOSOPHERS);
   test((i + 1) % NUM_PHILOSOPHERS);
}

void test(int i) {
   if ((state[(i + 4) % NUM_PHILOSOPHERS] != EATING) && (state[i] == HUNGRY) && (state[(i + 1) % NUM_PHILOSOPHERS] != EATING)) {
      state[i] = EATING;
      sem_post(&self[i]);
   }
}

void init_random() {
   time_t t;
   srand((unsigned) time(&t));
}

int get_random(int min, int max) {
   return (int)(rand() % (max - min)) + min;
}

void sleep_random(int min, int max) {
   usleep(get_random(min, max));
}
