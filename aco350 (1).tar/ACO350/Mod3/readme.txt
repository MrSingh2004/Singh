C:				Lecture		Notes
================================================================================================================================================
dining.c			ACO350_3c.pdf	Dining Philosophers problem in C.
RW_demo.c			ACO350_3c.pdf	Example of the Reader/Writer problem in C.
peterson.c			ACO350_3a.pdf	Example of Peterson's solution to teh Critical Section problem in C.
makefile					makefile to compile (make all) or delete (make clean)

Java:				Lecture		Notes
================================================================================================================================================
AllocationException.java	ACO350_3e.pdf	Part of the Bankers Algorithm program in Java (needed for Written Assignment 3).
Bankers.java			ACO350_3e.pdf	Part of the Bankers Algorithm program in Java (needed for Written Assignment 3).
BankersTest.java		ACO350_3e.pdf	Part of the Bankers Algorithm program in Java (needed for Written Assignment 3).
banker-1.txt			ACO350_3e.pdf	Data file for the Bankers Algorithm.
banker-2.txt			ACO350_3e.pdf	Data file for the Bankers Algorithm.
BoundedBuffer.java		ACO350_3b.pdf	Example of the Producer/Consumer problem on a Bounded Buffer in Java.
Stack_m.java			ACO350_3b.pdf	Example synchronized methods in Java.
makefile					makefile to compile (make all) or delete (make clean)

advisement:			Lecture		Notes
================================================================================================================================================
advisement.c			ACO350_3c.pdf	Starter C program to be completed for the assignment "Project 3 - Advisement".
sim1.txt			ACO350_3c.pdf	Data file for the advisement simulation.
sim2.txt			ACO350_3c.pdf	Data file for the advisement simulation.
sim3.txt			ACO350_3c.pdf	Data file for the advisement simulation.
makefile					makefile to compile (make all) or delete (make clean)
