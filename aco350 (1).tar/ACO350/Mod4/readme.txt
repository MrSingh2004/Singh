C:				Lecture		Notes
================================================================================================================================================
empty

Java:				Lecture		Notes
================================================================================================================================================
DemandPagingSimulation.java	ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
FIFOAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
LFUAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
LRUAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
MFUAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
OptimalAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
RandomAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
ReplacementAlgorithm.java	ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
ReplacementAlgorithmBase.java	ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
TrivialAlgorithm.java		ACO350_4e.pdf	Demand Paging Simulation program in Java (Needed for Written Assignment 4).
makefile					makefile to compile (make all) or delete (make clean)

array:				Lecture		Notes
================================================================================================================================================
Array.java 			ACO350_4b.pdf	Starter Java code to be completed for the assignment "Project 4 - Array Manager and Paged Arrays".
ArrayClient.java		ACO350_4b.pdf	Starter Java code to be completed for the assignment "Project 4 - Array Manager and Paged Arrays".
ArrayManager.java		ACO350_4b.pdf	Starter Java code to be completed for the assignment "Project 4 - Array Manager and Paged Arrays".
OutOfMemoryException.java	ACO350_4b.pdf	Starter Java code to be completed for the assignment "Project 4 - Array Manager and Paged Arrays".
SegmentationViolationException.java		
				ACO350_4b.pdf	Starter Java code to be completed for the assignment "Project 4 - Array Manager and Paged Arrays".
arr1.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr2.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr3.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr4.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr5.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr6.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
arr7.txt			ACO350_4b.pdf	Data file for the assignment "Project 4 - Array Manager and Paged Arrays".
makefile					makefile to compile (make all) or delete (make clean)
