import java.util.ArrayList;

public class ArrayManager {
	// Your instance variables here

	public ArrayManager(int numFrames, int frameSize) {
		// Your code here
	}

	public Array createArray(int size) throws OutOfMemoryException {
		// Your code here
		
		return null;
	}

	public Array aliasArray(Array a) {
		PagedArray pa = (PagedArray) a;

		// Your code here
		
		return null;
	}

	public void deleteArray(Array a) {
		PagedArray pa = (PagedArray) a;
		//
		// Your code here
	}

	public void resizeArray(Array a, int newSize) throws OutOfMemoryException {		
		PagedArray pa = (PagedArray) a;
      //
		// Your code here
	}

	public void printMemory() {
		// Your code here
	}

	private class PagedArray implements Array {
		// Your instance variables here

		public PagedArray(int pageTable[], int length) {
			// Your code here
		}

		public int getValue(int index) throws SegmentationViolationException {
			// Your code here
			
			return 0;
		}

		public void setValue(int index, int val) throws SegmentationViolationException {
			// Your code here
		}

		public String toString() {
			// Your code here
			
			return "";
		}

		public int[] getPageTable() {
			// Your code here
			
			return null;
		}
		
		public void setPageTable(int[] pageTable) {
			// Your code here
		}
		
		public int length() {
			// Your code here
			
			return 0;
		}
		
		public void setLength(int length) {
			// Your code here
		}
	}
}
