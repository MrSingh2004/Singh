public class OutOfMemoryException extends RuntimeException {
}
