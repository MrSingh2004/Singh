public class SegmentationViolationException extends RuntimeException {
}
