public class Sum {
   private int value;
   
   public Sum() {
      value = 0;
   }
   
   public void add(int a) {
      value += a;
   }
   
   public int getValue() {
      return value;
   }
}
