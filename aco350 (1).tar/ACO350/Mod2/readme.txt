C:				Lecture		Notes
================================================================================================================================================
item-consumer.c			ACO350_2b.pdf	Example Producer/Consumer problem in C.
item-producer.c			ACO350_2b.pdf	Example Producer/Consumer problem in C.
newproc-posix.c			ACO350_2b.pdf	Example multi-process code in C.
newproc-return.c		ACO350_2b.pdf	Example multi-process code in C.
omp-1.c				ACO350_2e.pdf	Open MP example in C.
omp-2.c				ACO350_2e.pdf	Open MP example in C.
omp-3.c				ACO350_2e.pdf	Open MP example in C.
thrd-multisum.c			ACO350_2d.pdf	Example POSIX multi-threaded example in C.
thrd-sum.c			ACO350_2d.pdf	Example POSIX multi-threaded example in C.
two-way-pipes.c			ACO350_2c.pdf	Example interprocess communication with pipes in C
unix-pipe.c			ACO350_2c.pdf	Example interprocess communication with pipes in C
makefile					makefile to compile (make all) or delete (make clean)

Java:				Lecture		Notes
================================================================================================================================================
DateClient.java			ACO350_2c.pdf	Example client/server code in Java.
DateServer.java			ACO350_2c.pdf	Example client/server code in Java.
RangeRunner.java		ACO350_2e.pdf	Example multi-threaded Java code.
Runner.java			ACO350_2e.pdf	Example multi-threaded Java code.
Sum.java			ACO350_2e.pdf	Example multi-threaded Java code.
SumTask.java			ACO350_2e.pdf	Example multi-threaded Java code.
ThreadMultiSum.java		ACO350_2e.pdf	Example multi-threaded Java code.
ThreadSum.java			ACO350_2e.pdf	Example multi-threaded Java code.
makefile					makefile to compile (make all) or delete (make clean)

matrix:				Lecture		Notes
================================================================================================================================================
matrix-mult.c 			ACO350_2d.pdf	Starter C program to be completed for the assignment "Project 2b - Matrix Multiplication"
data1.txt			ACO350_2d.pdf	Data file for the Matrix Multiplication project.
data2.txt			ACO350_2d.pdf	Data file for the Matrix Multiplication project.
makefile					makefile to compile (make all) or delete (make clean)

name:				Lecture		Notes
================================================================================================================================================
NameClient.java 		ACO350_2c.pdf	Starter Java program to be completed for the assignment "Project 2a - Name Lookup"
makefile					makefile to compile (make all) or delete (make clean)
